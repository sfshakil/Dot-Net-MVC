﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UniversityCourseManagementSystemApp.Models
{
    public class TeacherDesignation
    {
        public int Id { get; set; }
        public int DesignationId { get; set; }
        public string DesignationName { get; set; }

    }
}